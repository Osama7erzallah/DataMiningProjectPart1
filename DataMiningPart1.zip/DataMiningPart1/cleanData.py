import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import skew

# Load the dataset from a CSV file named "airBnb.csv"
data = pd.read_csv("./airBnb.csv")

# Display the structure of the loaded dataset
print(data.info())

# Replace spaces with underscores in all column names
data.columns = data.columns.str.replace(' ', '_')

# Replace dollar and comma signs and convert columns to numeric
data['service_fee'] = pd.to_numeric(data['service_fee'].replace('[\$,]', '', regex=True))

# Drop columns that we don't need
data = data.drop(columns=['id', 'host_id', 'host_name', 'country', 'availability_365'])

# Replace dollar signs and commas in the 'price' column and convert to numeric
data['price'] = pd.to_numeric(data['price'].replace('[\$,]', '', regex=True))

# Replace empty values with NA
data.replace("", np.nan, inplace=True)

# Calculate the percentage of missing values in each column of the dataset
missing_percentage = (data.isnull().sum() / len(data)) * 100

# Plot the missing percentage
plt.figure(figsize=(10, 6))
missing_percentage.plot(kind='bar')
plt.title('Missing Percentage')
plt.xlabel('Columns')
plt.ylabel('Percentage')
plt.show()

# Get the column names with missing percentages greater than 15
columns_to_drop = missing_percentage[missing_percentage > 15].index

# Drop the specified columns with high missing percentages
data = data.drop(columns=columns_to_drop)

# Drop rows with missing values >= 30%
threshold_percentage = 30
data = data[data.isnull().mean(axis=1) < threshold_percentage / 100]

# Replace missing values with median for each numeric column
numeric_columns = data.select_dtypes(include='number').columns
data[numeric_columns] = data[numeric_columns].fillna(data[numeric_columns].median())

# Fill logical missing values with the mode value of the column
data['instant_bookable'].fillna(data['instant_bookable'].mode().iloc[0], inplace=True)

# Replace missing values with mode for each nominal column
data = data.apply(lambda x: x.fillna(x.mode().iloc[0]) if x.dtype == "O" else x)

# Check if there are any remaining missing values and plot it
plt.figure(figsize=(10, 6))
data.isnull().sum().plot(kind='bar')
plt.title('Remaining Missing Values')
plt.xlabel('Columns')
plt.ylabel('Count')
plt.show()

# Remove duplicates from filled-dataset
data = data.drop_duplicates()

# Check if there are any remaining duplicates
print("Number of remaining duplicates:", data.duplicated().sum())

# Create an empty list to store statistics
statistics_data = []

# Boxplot for numeric values
numeric_columns = ["Construction_year", "price", "service_fee"]
data[numeric_columns].boxplot()
plt.title('Boxplot of Numeric Columns')
plt.show()

# Individual Boxplots for Numeric Values
for column in numeric_columns:
    plt.figure(figsize=(8, 5))
    data[column].plot(kind='box')
    plt.title(f'Boxplot of {column}')
    plt.show()

    # Calculate central tendency, Maximum, Minimum
    mean_value = data[column].mean()
    median_value = data[column].median()
    max_value = data[column].max()
    min_value = data[column].min()
    mode_value = data[column].mode().iloc[0]

    # Append the statistics to the list
    statistics_data.append({
        'Column': column,
        'Mean': mean_value,
        'Median': median_value,
        'Mode': mode_value,
        'Maximum': max_value,
        'Minimum': min_value
    })

# Calculate skewness_value
    skewness_value = skew(data[column])
    print(f"column:{column}")
    print(f"Skewness: {skewness_value}")
# Create a DataFrame from the list
statistics_table = pd.DataFrame(statistics_data)

# Display the statistics table
print("\nStatistics Table for Numeric Columns:")
print(statistics_table)

# Write the cleaned dataset to a CSV file named "cleaned_dataset.csv"
data.to_csv("./cleaned_dataset.csv", index=False)
